<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\QA;
use Exception;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class QAController extends Controller
{
    public function add(Request $request){
        try{
            QA::create([
                'user_id' => Auth::user()->pf,
                'project_id' => $request->project_id,
                'serial' => $request->serial,
                'set_date' => Carbon::parse($request->set_date)->format('Y-m-d'),
                'description' => $request->description,
                'status' => $request->status,
                'revision' => $request->revision,
                'form' => $request->form
            ]);
        }
        catch(Exception $e){
            return $e;
        }
    }

    public function get(Request $request){
        try{
            $user_type = Auth::user()->type;
            if($user_type == 'Manager'){
                return QA::where('form', $request->form)->get();
            }
            else{
                return QA::where([
                    ['form', $request->form], 
                    ['user_id', Auth::user()->pf]
                ])->get();
            }
        }
        catch(Exception $e){
            return $e;
        }
    }

    public function all(Request $request){
        try{
            return QA::all();
        }
        catch(Exception $e){
            return $e;
        }
    }

    public function selected(Request $request){
        try{
            return QA::where('serial', $request->serial)->first();
        }
        catch(Exception $e){
            return $e;
        }
    }

    public function update(Request $request){
        try{
            QA::where('serial', $request->serial)->update([
                'project_id' => $request->project_id,
                'set_date' => Carbon::parse($request->set_date)->format('Y-m-d'),
                'description' => $request->description,
                'status' => $request->status,
                'revision' => $request->revision,
                'form' => $request->form
            ]);
        }
        catch(Exception $e){
            return $e;
        }
    }

    public function delete(Request $request){
        try{
            return QA::where('serial', $request->serial)->delete();
        }
        catch(Exception $e){
            return $e;
        }
    }
}

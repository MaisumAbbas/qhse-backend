<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Project;
use App\Models\ProjectRemark;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\ProjectEmail;

class ProjectController extends Controller
{
    public function index(){
        return '';
    }

    public function add(Request $request){
        try{
            $project_id = Project::create([
                'job' => $request->job,
                'title' => $request->title,
                'location' => $request->location,
                'department_id' => (int)$request->department_id,
                'client' => $request->client,
                'assigned_manager' => $request->assigned_manager,
                'active' => $request->active,
                'user_id' => Auth::user()->pf
            ])->job;

            if(isset($request->remarks)){
                foreach ($request->remarks as $remark) {
                    ProjectRemark::create([
                        'code' => $remark['code'],
                        'remarks' => $remark['remark'],
                        'project_id' => $project_id
                    ]);
                }
            }
            
            $user = User::where('pf', $request->assigned_manager)->first();
            $data = array(
                'name' => $user['first_name'] . ' ' . $user['last_name']
            );
            Mail::to($user['email'])->send(new ProjectEmail($data));
            
        }
        catch(Exception $e){
            return response()->json([
                'error' => $e->getCode()
            ]);
        }

        return response()->json('success');
    }

    public function projectList(){
        try{
            return Project::all();
        }
        catch(Exception $e){
            return response()->json([
                'error' => $e->getCode()
            ]);
        }
    }

    public function get(){
        try{
            return Project::with('getProjectManager')->get();
        }
        catch(Exception $e){
            return response()->json([
                'error' => $e->getCode()
            ]);
        }
    }

    public function selected(Request $request){
        try{
            return Project::with('getProjectRemark')->where('job', $request->old_id)->first();
        }
        catch(Exception $e){
            return response()->json([
                'error' => $e->getCode()
            ]);
        }
    }

    public function update(Request $request){
        try{
            Project::where('job', $request->old_id)->update([
                'title' => $request->title,
                'location' => $request->location,
                'department_id' => (int)$request->department_id,
                'client' => $request->client,
                'assigned_manager' => $request->assigned_manager,
                'active' => $request->active,
            ]);

            ProjectRemark::where('project_id', $request->old_id)->delete();
            if(isset($request->remarks)){
                foreach ($request->remarks as $remark) {
                    ProjectRemark::create([
                        'code' => $remark['code'],
                        'remarks' => $remark['remark'],
                        'project_id' => $request->old_id
                    ]);
                }
            }
        }
        catch(Exception $e){
            return response()->json([
                'error' => $e->getCode()
            ]);
        }
    }

    public function delete(Request $request){
        try{
            return Project::where('job', $request->old_id)->delete();
        }
        catch(Exception $e){
            return response()->json([
                'error' => $e->getCode()
            ]);
        }
    }
}
